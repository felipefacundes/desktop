#ifndef _conkyrc_default_
#define _conkyrc_default_

void conkyrc_default ();

#endif // #ifndef _conkyrc_default_
