#ifndef _install_
#define _install_

int confinstall();

#endif // #ifndef _install_
