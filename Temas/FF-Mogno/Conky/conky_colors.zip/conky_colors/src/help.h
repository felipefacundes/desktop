#ifndef _help_
#define _help_

void help();

#endif // #ifndef _help_
