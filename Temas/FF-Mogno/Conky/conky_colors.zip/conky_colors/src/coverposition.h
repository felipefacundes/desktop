#ifndef _coverposition_
#define _coverposition_

//Cover Position
void coverposition ();
void coverposition_cairo ();
void coverposition_ring ();

#endif // #ifndef _coverposition_
