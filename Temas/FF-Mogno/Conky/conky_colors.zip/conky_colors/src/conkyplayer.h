#ifndef _conkyplayer_
#define _conkyplayer_

//Create and write conkyPlayer.template
void conkyplayer ();

#endif // #ifndef _conkyplayer_
