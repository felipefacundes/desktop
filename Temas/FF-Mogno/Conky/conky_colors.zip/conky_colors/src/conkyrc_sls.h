#ifndef _conkyrc_sls_
#define _conkyrc_sls_

void conkyrc_sls ();

#endif // #ifndef _conkyrc_sls_
