#ifndef _photoposition_
#define _photoposition_

//Photo Position
void photoposition ();

#endif // #ifndef _photoposition_
