#ifndef _translations_
#define _translations_

extern char 	sys[31],
		processes[31],
		battery[31],
		uptime[31],
		packages[31],
		date[31],
		photo[31],
		hd[31],
		temperature[31],
		network[31],
		total[31],
		up[31],
		down[31],
		//upload[31],
		//download[31],
		sinal[31],
		localip[31],
		publicip[31],
		nonet[31],
		Weather[31],
		noweather[31],
		//station[31],
		//rain[31],
		humidity[31],
		//sunrise[31],
		//sunset[31],
		//moon[31],
		updates[31],
		nouve[31],
		status[31],
		song[31],
		tempo[31],
		nopidgin[31],
		//norhythmbox[31],
		unknownstatus[31];

extern char 	language[31];

//Languages
void translation ();

#endif // #ifndef _translations_
