#ifndef _utils_
#define _utils_

int strncpycmd(char *dest, const char * cmd, size_t size);
int systemf(const char* format, ...);
FILE *fopenf(const char* format, const char* mode, ...);

#endif // #ifndef _strcpycmd_

