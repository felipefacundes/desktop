#ifndef _initialize_
#define _initialize_

int initialize();

#endif // #ifndef _initialize_
