#ifndef _themes_
#define _themes_


extern int 	radiance, ambiance, elementary, custom,
		    dark, black, white;

extern char 	theme[31],
		defaultcolor[31],
		color0[31],
		color1[31],
		color2[31],
		color3[31],
		color4[31];

void themes();

#endif // #ifndef _themes_
