#!/bin/sh
# conkycalender.sh
# by Crinos512
# Usage:
#  ${execp ~/.conky/conkyparts/conkycalender.sh}
#
DJS=`date +%_d`
Month=`date +'%B %Y' | tr '[:lower:]' '[:upper:]'`

echo "$Month ${color1}${hr 1}${color}${font Liberation Mono:size=8}"
for i in {1..7}
do
  Text=`cal | sed '1d' | sed '/./!d' | sed 's/$/                     /' | sed -n '/^.{21}/p' | head -n $i | tail -n 1 | sed -n '/^.{21}/p' | sed 's/^/${alignc} /' | sed /" $DJS "/s/" $DJS "/" "'${color2}'"$DJS"'${color}'" "/`
  echo "${goto 130}$Text"
done
echo "${font}"

exit 0
