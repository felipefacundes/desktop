#!/usr/bin/env bash

# colored ls
export LSCOLORS='Gxfxcxdxdxegedabagacad'
alias ls='ls -G'
