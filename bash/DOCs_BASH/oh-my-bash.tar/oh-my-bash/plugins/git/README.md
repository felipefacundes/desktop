# Git Plugin

The git plugin defines a number of useful aliases for you. [Consult the complete list](git.plugin.sh#L34)
