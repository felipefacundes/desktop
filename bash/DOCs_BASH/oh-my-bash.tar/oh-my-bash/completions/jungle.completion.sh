[[ -x "$(which jungle)" ]] &>/dev/null  && eval "$(_JUNGLE_COMPLETE=source jungle)"
