#!/bin/bash
cd /home/maria/.local/bin/lembrete_repetitivo/;
nohup ./sequenciadorLR &
exit